# Bobby1545 Powers — Fabric Mod (Minecraft 1.21.5)

Bu mod, oyuncuya Bobby1545 creepypasta'sından esinlenilen şimşek güçleri ekler.

## Özellikler

- **Tekli Şimşek (sağ tık, boş el, kısa basış):** Baktığın mob veya oyuncuya tek şimşek düşürür. ~2 saniye bekleme süresi (cooldown) var.
- **Ulti (sağ tık, boş el, ~3 saniye basılı tut):** Etrafındaki 15 blok yarıçap içindeki **tüm** canlılara (mob + oyuncu) şimşek çarpar. Kullandıktan sonra karakter sersemler (yavaşlar, mide bulanması efekti), ~1 dakika bekleme süresine girer.

İki yetenek de aynı tuşu (sağ tık) kullanır ama çakışmaz: tuşu kısa basıp bırakırsan tekli şimşek, 3 saniye basılı tutarsan sadece ulti tetiklenir.

## Telefondan Derleme (GitHub Codespaces ile)

Bilgisayarın olmadığı için bu projeyi tarayıcı üzerinden (telefon dahil) derleyebilirsin:

1. **GitHub hesabı aç** (yoksa): https://github.com/signup
2. Bu proje klasörünü bir GitHub reposuna yükle:
   - En basit yol: GitHub'da yeni bir repo oluştur ("bobby1545mod" gibi bir isimle), sonra "Add file > Upload files" ile bu klasördeki tüm dosyaları (alt klasörler dahil) yükle. Telefon tarayıcısı çoklu dosya/klasör yüklemeyi destekler.
3. Repo sayfasında yeşil **"Code"** butonuna bas → **"Codespaces"** sekmesi → **"Create codespace on main"**
4. Codespace açılınca (tarayıcı içinde VS Code arayüzü), alt kısımdaki **Terminal**'i aç
5. Şu komutu çalıştır (wrapper dosyalarını otomatik oluşturur):
   ```
   gradle wrapper --gradle-version 8.10
   ```
6. Ardından derlemeyi başlat:
   ```
   ./gradlew build
   ```
7. İlk derleme biraz sürer (bağımlılıklar indirilir). Bitince çıkan `.jar` dosyası şurada olacak:
   ```
   build/libs/bobby1545mod-1.0.0.jar
   ```
8. Bu dosyayı Codespaces dosya gezgininden indir (sağ tık > Download), sonra tanıdığına gönder.

## Tanıdığının Bilgisayarında Kurulum

1. Minecraft Java Edition 1.21.5 yüklü olmalı
2. **Fabric Loader** kurulu olmalı (https://fabricmc.net/use/installer/ adresinden)
3. **Fabric API** modu da `mods` klasörüne eklenmeli (bu mod ona bağımlı) — Modrinth veya CurseForge'dan "Fabric API" 1.21.5 sürümü indirilebilir
4. Bizim ürettiğimiz `bobby1545mod-1.0.0.jar` dosyası da aynı `mods` klasörüne konur
   - Windows: `%appdata%\.minecraft\mods`
   - Mac: `~/Library/Application Support/minecraft/mods`
5. Minecraft'ı Fabric profiliyle başlat

## Notlar

- Şimşek hasarı vanilla Minecraft şimşek hasarı gibi çalışır (gerçek hasar verir, sadece görsel değil).
- Ulti yarıçapı, cooldown süreleri gibi değerler `Bobby1545Mod.java` dosyasının başındaki sabitlerden değiştirilebilir.
