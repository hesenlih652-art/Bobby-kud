package com.bobby1545mod.client;

import com.bobby1545mod.SingleBoltTriggerPayload;
import com.bobby1545mod.UltimateTriggerPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;

public class Bobby1545ModClient implements ClientModInitializer {

	// Basılı tutma sayacı (3 saniye = 60 tick)
	private int holdTicks = 0;
	private static final int REQUIRED_HOLD_TICKS = 60;
	private boolean ultimateFired = false;
	private boolean wasHoldingLastTick = false;

	@Override
	public void onInitializeClient() {

		// Network paket tiplerini client tarafında da kaydet
		PayloadTypeRegistry.playC2S().register(UltimateTriggerPayload.ID, UltimateTriggerPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(SingleBoltTriggerPayload.ID, SingleBoltTriggerPayload.CODEC);

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.player == null || client.world == null) {
				resetState();
				return;
			}

			boolean emptyHand = client.player.getStackInHand(Hand.MAIN_HAND).isEmpty();
			boolean usingItemKeyHeld = client.options.useKey.isPressed();
			boolean holdingNow = emptyHand && usingItemKeyHeld;

			if (holdingNow) {
				holdTicks++;

				// Görsel ipucu: belirli aralıklarla parçacık efekti göster (şarj oluyor hissi)
				if (holdTicks % 5 == 0 && holdTicks < REQUIRED_HOLD_TICKS) {
					client.world.addParticle(
							ParticleTypes.ELECTRIC_SPARK,
							client.player.getX(),
							client.player.getY() + 1.0,
							client.player.getZ(),
							0, 0.1, 0
					);
				}

				// 3 saniyeye ulaşınca ulti paketi gönder (sadece bir kere)
				if (holdTicks >= REQUIRED_HOLD_TICKS && !ultimateFired) {
					ultimateFired = true;
					ClientPlayNetworking.send(new UltimateTriggerPayload(true));
					client.player.sendMessage(Text.literal("§eBobby1545 gücü serbest bırakıldı!"), true);
				}
			} else {
				// Tuş bu tick'te basılı değil. Önceki tick'te basılıydı mı kontrol et (bırakma anı).
				if (wasHoldingLastTick && !ultimateFired && holdTicks > 0) {
					// Ulti tetiklenmeden bırakıldı -> bu kısa bir tıklamaydı, tekli şimşek gönder
					ClientPlayNetworking.send(new SingleBoltTriggerPayload(true));
				}
				resetState();
			}

			wasHoldingLastTick = holdingNow;
		});
	}

	private void resetState() {
		holdTicks = 0;
		ultimateFired = false;
	}
}

