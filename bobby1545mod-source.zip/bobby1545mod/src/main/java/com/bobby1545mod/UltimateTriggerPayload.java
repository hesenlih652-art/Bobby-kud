package com.bobby1545mod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * Client'tan sunucuya gönderilen "ulti tetiklendi" paketi.
 * Client tarafında 3 saniyelik basılı tutma tamamlanınca bu paket gönderilir.
 */
public record UltimateTriggerPayload(boolean trigger) implements CustomPayload {

	public static final CustomPayload.Id<UltimateTriggerPayload> ID =
			new CustomPayload.Id<>(Identifier.of("bobby1545mod", "ultimate_trigger"));

	public static final PacketCodec<RegistryByteBuf, UltimateTriggerPayload> CODEC =
			PacketCodec.tuple(
					PacketCodec.of((value, buf) -> buf.writeBoolean(value), RegistryByteBuf::readBoolean),
					UltimateTriggerPayload::trigger,
					UltimateTriggerPayload::new
			);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
