package com.bobby1545mod;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

public class Bobby1545Network {

	public static void registerServer() {
		// Paket tiplerini kaydet (client -> server)
		PayloadTypeRegistry.playC2S().register(UltimateTriggerPayload.ID, UltimateTriggerPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(SingleBoltTriggerPayload.ID, SingleBoltTriggerPayload.CODEC);

		// Sunucu tarafında ulti paketini alınca ulti'yi tetikle
		ServerPlayNetworking.registerGlobalReceiver(UltimateTriggerPayload.ID, (payload, context) -> {
			ServerPlayerEntity player = context.player();
			context.server().execute(() -> {
				if (payload.trigger()) {
					Bobby1545Mod.triggerUltimate(player);
				}
			});
		});

		// Sunucu tarafında tekli şimşek paketini alınca tekli şimşeği tetikle
		ServerPlayNetworking.registerGlobalReceiver(SingleBoltTriggerPayload.ID, (payload, context) -> {
			ServerPlayerEntity player = context.player();
			context.server().execute(() -> {
				if (payload.trigger()) {
					Bobby1545Mod.triggerSingleBolt(player);
				}
			});
		});
	}
}
