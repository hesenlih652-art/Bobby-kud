package com.bobby1545mod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.LightningEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class Bobby1545Mod implements ModInitializer {

	// Her oyuncunun sağ tık (tekli şimşek) cooldown durumu (tick sayacı)
	public static final Map<UUID, Integer> singleBoltCooldown = new HashMap<>();

	// Her oyuncunun ulti (alan şimşeği) cooldown durumu (tick sayacı)
	public static final Map<UUID, Integer> ultimateCooldown = new HashMap<>();

	// Her oyuncunun şu anki basılı tutma süresi (tick sayacı)
	public static final Map<UUID, Integer> chargeTicks = new HashMap<>();

	// Sersemleme (ulti sonrası yere düşme) durumundaki oyuncular
	public static final Map<UUID, Integer> staggerTicks = new HashMap<>();

	// Ayarlar (tick = 1/20 saniye)
	public static final int SINGLE_BOLT_COOLDOWN_TICKS = 40;   // ~2 saniye
	public static final int ULTIMATE_CHARGE_TICKS = 60;        // 3 saniye basılı tutma
	public static final int ULTIMATE_COOLDOWN_TICKS = 1200;    // ~60 saniye (1 dakika)
	public static final int ULTIMATE_RADIUS = 15;              // 15 blok yarıçap
	public static final int STAGGER_DURATION_TICKS = 30;       // ~1.5 saniye sersemleme
	public static final double RAY_TRACE_DISTANCE = 40.0;      // bakış menzili

	@Override
	public void onInitialize() {

		// Not: Tekli şimşek artık UseItemCallback ile DEĞİL, network paketi ile tetikleniyor.
		// Sebep: sağ tık tuşuna basmanın ilk anında ateşlenirse, ulti için basılı tutulduğunda
		// da gereksiz şekilde tekli şimşek düşer. Bunun yerine client (Bobby1545ModClient),
		// tuş ~5 tick içinde bırakılırsa SingleBoltTriggerPayload gönderir; tuş basılı kalıp
		// 60 tick'e ulaşırsa UltimateTriggerPayload gönderir. Böylece ikisi asla çakışmaz.

		// --- Sunucu tick: cooldown sayaçları, sersemleme ---
		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
			// Respawn olunca sayaçları sıfırla
			UUID id = newPlayer.getUuid();
			singleBoltCooldown.remove(id);
			ultimateCooldown.remove(id);
			chargeTicks.remove(id);
			staggerTicks.remove(id);
		});

		net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
				UUID id = player.getUuid();

				// Cooldown sayaçlarını azalt
				singleBoltCooldown.computeIfPresent(id, (k, v) -> Math.max(0, v - 1));
				ultimateCooldown.computeIfPresent(id, (k, v) -> Math.max(0, v - 1));

				// Sersemleme durumu: hareketi yavaşlat, süre dolunca kaldır
				Integer stagger = staggerTicks.get(id);
				if (stagger != null && stagger > 0) {
					player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 10, 4, false, false, true));
					staggerTicks.put(id, stagger - 1);
					if (stagger - 1 <= 0) {
						staggerTicks.remove(id);
					}
				}

				// Not: Basılı tutma süresi client tarafında ölçülüyor (Bobby1545ModClient).
				// 3 saniye dolunca client, UltimateTriggerPayload paketini sunucuya gönderir
				// ve Bobby1545Network bu paketi alıp triggerUltimate(player) çağırır.
			}
		});

		Bobby1545Network.registerServer();

		System.out.println("[Bobby1545Mod] Mod yüklendi - şimşek yetenekleri aktif.");
	}

	/**
	 * Oyuncunun baktığı canlı varlığı (mob veya oyuncu, kendisi hariç) bulur.
	 */
	public static LivingEntity getLookedAtLivingEntity(ServerPlayerEntity player, double maxDistance) {
		World world = player.getWorld();
		Vec3d start = player.getCameraPosVec(1.0f);
		Vec3d look = player.getRotationVec(1.0f);
		Vec3d end = start.add(look.multiply(maxDistance));

		Box searchBox = player.getBoundingBox().stretch(look.multiply(maxDistance)).expand(1.0);

		LivingEntity closest = null;
		double closestDistance = maxDistance;

		for (net.minecraft.entity.Entity entity : world.getOtherEntities(player, searchBox,
				e -> e instanceof LivingEntity && e.isAlive() && e != player)) {

			Box entityBox = entity.getBoundingBox().expand(0.3);
			java.util.Optional<Vec3d> hit = entityBox.raycast(start, end);

			if (hit.isPresent()) {
				double distance = start.distanceTo(hit.get());
				if (distance < closestDistance) {
					closestDistance = distance;
					closest = (LivingEntity) entity;
				}
			}
		}

		return closest;
	}

	/**
	 * Belirtilen koordinata vanilla görsel/sesli efektli yıldırım düşürür.
	 * EntityType.LIGHTNING_BOLT kullanılır, hasar vanilla şimşek hasarı gibi işler.
	 */
	public static void strikeLightning(MinecraftServer server, double x, double y, double z) {
		if (server == null) return;
		var world = server.getOverworld();
		LightningEntity bolt = net.minecraft.entity.EntityType.LIGHTNING_BOLT.create(world, net.minecraft.entity.SpawnReason.TRIGGERED);
		if (bolt != null) {
			bolt.refreshPositionAfterTeleport(x, y, z);
			bolt.setCosmetic(false); // false = gerçek hasar verir
			world.spawnEntity(bolt);
		}
	}

	/**
	 * Tekli şimşek: oyuncunun baktığı hedefe (varsa) tek şimşek düşürür.
	 * Client'tan SingleBoltTriggerPayload geldiğinde çağrılır.
	 */
	public static void triggerSingleBolt(ServerPlayerEntity player) {
		UUID id = player.getUuid();
		if (singleBoltCooldown.getOrDefault(id, 0) > 0) {
			return;
		}

		LivingEntity target = getLookedAtLivingEntity(player, RAY_TRACE_DISTANCE);
		if (target != null) {
			strikeLightning(player.getServer(), target.getX(), target.getY(), target.getZ());
			singleBoltCooldown.put(id, SINGLE_BOLT_COOLDOWN_TICKS);
		}
	}

	/**
	 * Ulti: belirtilen oyuncunun etrafındaki yarıçap içindeki tüm canlılara (kendisi hariç) şimşek çarpar.
	 */
	public static void triggerUltimate(ServerPlayerEntity player) {
		UUID id = player.getUuid();
		if (ultimateCooldown.getOrDefault(id, 0) > 0) {
			return;
		}

		World world = player.getWorld();
		Box area = player.getBoundingBox().expand(ULTIMATE_RADIUS);

		for (net.minecraft.entity.Entity entity : world.getOtherEntities(player, area,
				e -> e instanceof LivingEntity && e.isAlive() && e != player)) {
			LivingEntity living = (LivingEntity) entity;
			double dist = player.getPos().distanceTo(living.getPos());
			if (dist <= ULTIMATE_RADIUS) {
				strikeLightning(player.getServer(), living.getX(), living.getY(), living.getZ());
			}
		}

		// Karakter "yere düşer" - sersemleme efekti + kısa süre yavaşlatma
		staggerTicks.put(id, STAGGER_DURATION_TICKS);
		player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, STAGGER_DURATION_TICKS, 4, false, false, true));
		player.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, STAGGER_DURATION_TICKS, 0, false, false, true));

		// Cooldown başlat
		ultimateCooldown.put(id, ULTIMATE_COOLDOWN_TICKS);
	}
}
