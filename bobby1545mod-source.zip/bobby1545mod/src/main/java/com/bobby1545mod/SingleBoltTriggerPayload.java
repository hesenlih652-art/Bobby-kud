package com.bobby1545mod;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * Client'tan sunucuya gönderilen "tekli şimşek tetiklendi" paketi.
 * Client tarafında sağ tık tuşu kısa süre (REQUIRED_HOLD_TICKS'ten önce) bırakılınca gönderilir.
 */
public record SingleBoltTriggerPayload(boolean trigger) implements CustomPayload {

	public static final CustomPayload.Id<SingleBoltTriggerPayload> ID =
			new CustomPayload.Id<>(Identifier.of("bobby1545mod", "single_bolt_trigger"));

	public static final PacketCodec<RegistryByteBuf, SingleBoltTriggerPayload> CODEC =
			PacketCodec.tuple(
					PacketCodec.of((value, buf) -> buf.writeBoolean(value), RegistryByteBuf::readBoolean),
					SingleBoltTriggerPayload::trigger,
					SingleBoltTriggerPayload::new
			);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
